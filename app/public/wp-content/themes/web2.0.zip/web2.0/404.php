<?php get_header(); ?>
<main class="container text-center">
    <p style="font-size: 100px">Sorry, page not found 404 :(</p>

</main>
<?php get_footer()?>