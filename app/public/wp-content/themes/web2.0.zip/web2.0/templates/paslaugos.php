<?php
/*
Template Name: Paslaugos
*/
?>
<?php get_header(); ?>

<main>
    Paslaugos
</main>

<?php get_footer(); ?>
