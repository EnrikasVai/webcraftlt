<?php
/*
Template Name: Apie Mus
*/
?>
<?php get_header(); ?>

<main>
    Apie mus
</main>

<?php get_footer(); ?>
