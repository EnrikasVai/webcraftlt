<?php
/*
Template Name: Privatumo politika
*/
?>
<?php get_header(); ?>

<main>
    Privatumo politika
</main>

<?php get_footer(); ?>
