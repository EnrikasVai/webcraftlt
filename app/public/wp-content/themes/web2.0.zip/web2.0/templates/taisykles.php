<?php
/*
Template Name: Taisykles
*/
?>
<?php get_header(); ?>

<main>
    Taisykles
</main>

<?php get_footer(); ?>
